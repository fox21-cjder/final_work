﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System;
using System.Windows.Forms;
using NAudio.Wave;

namespace AlarmClockApp
{
    public partial class Form1 : Form
    {
        // Объявление переменных
        private int Music = 0;                   // Флаг: 1 - музыка воспроизводится, 0 - нет
        private string NameFile = "";            // Путь до выбранного mp3 файла
        private string Hour = "";                // Часы, введённые пользователем
        private string Minutes = "";             // Минуты, введённые пользователем
        private string Seconds = "";             // Секунды, введённые пользователем
        private string HourNow = "";             // Текущие часы системы
        private string MinutesNow = "";          // Текущие минуты системы
        private string SecondsNow = "";          // Текущие секунды системы

        // Переменные для воспроизведения аудио через NAudio
        private WaveOutEvent waveOut;
        private AudioFileReader audioFileReader;

        public Form1()
        {
            InitializeComponent();
        }

        // Обработчик загрузки формы – заполняем текстбоксы текущим временем
        private void Form1_Load(object sender, EventArgs e)
        {
            int h = DateTime.Now.Hour;
            int m = DateTime.Now.Minute;
            int s = DateTime.Now.Second;

            string strH = h < 10 ? "0" + h.ToString() : h.ToString();
            string strM = m < 10 ? "0" + m.ToString() : m.ToString();
            string strS = s < 10 ? "0" + s.ToString() : s.ToString();

            textBox1.Text = strH;
            textBox2.Text = strM;
            textBox3.Text = strS;
        }

        // Универсальный обработчик KeyPress для всех TextBox (разрешаем ввод только цифр и Backspace)
        private void textBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)8)
            {
                e.Handled = true;
            }
            TextBox tb = sender as TextBox;
            if (tb != null && char.IsDigit(e.KeyChar) && tb.Text.Length >= 2)
            {
                e.Handled = true;
            }
        }

        // Универсальный обработчик Leave для форматирования ввода (добавляем ведущий 0, если введено одна цифра)
        private void textBox_Leave(object sender, EventArgs e)
        {
            TextBox tb = sender as TextBox;
            if (tb != null && tb.Text.Length == 1)
            {
                tb.Text = "0" + tb.Text;
            }
        }

        // Обработчик кнопки "Выбрать песню mp3"
        private void button1_Click(object sender, EventArgs e)
        {
            if (Music == 0)
            {
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    NameFile = openFileDialog1.FileName;
                    string extension = System.IO.Path.GetExtension(NameFile).ToLower();
                    if (extension != ".mp3")
                    {
                        MessageBox.Show("Выбран неверный формат файла. Пожалуйста, выберите файл формата mp3.",
                                        "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        NameFile = "";
                        return;
                    }
                    // Отображаем в кнопке укороченный путь (до 14 символов) с троеточием
                    if (NameFile.Length > 14)
                        button1.Text = NameFile.Substring(0, 14) + "...";
                    else
                        button1.Text = NameFile;
                }
            }
            else
            {
                // Если музыка уже воспроизводится, останавливаем воспроизведение
                StopSound();
                Music = 0;
                button1.Text = "Выбрать песню mp3";
            }
        }

        // Обработчик кнопки "Запустить" / "Стоп"
        private void button2_Click(object sender, EventArgs e)
        {
            if (button2.Text == "Стоп")
            {
                timer1.Stop();
                if (Music == 1)
                {
                    StopSound();
                    Music = 0;
                }
                // Разблокируем поля для редактирования
                textBox1.ReadOnly = false;
                textBox2.ReadOnly = false;
                textBox3.ReadOnly = false;
                button2.Text = "Запустить";
            }
            else
            {
                // Проверяем, что все поля заполнены и выбран файл mp3
                if (string.IsNullOrWhiteSpace(textBox1.Text) ||
                    string.IsNullOrWhiteSpace(textBox2.Text) ||
                    string.IsNullOrWhiteSpace(textBox3.Text) ||
                    string.IsNullOrWhiteSpace(NameFile))
                {
                    MessageBox.Show("Пожалуйста, заполните все поля и выберите файл mp3.",
                                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Проверяем корректность числовых значений
                if (int.TryParse(textBox1.Text, out int h) &&
                    int.TryParse(textBox2.Text, out int m) &&
                    int.TryParse(textBox3.Text, out int s))
                {
                    if (h < 0 || h > 23)
                    {
                        MessageBox.Show("Часы должны быть от 0 до 23.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    if (m < 0 || m > 59)
                    {
                        MessageBox.Show("Минуты должны быть от 0 до 59.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    if (s < 0 || s > 59)
                    {
                        MessageBox.Show("Секунды должны быть от 0 до 59.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }
                else
                {
                    MessageBox.Show("Неверный формат данных.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Сохраняем введённые значения
                Hour = textBox1.Text;
                Minutes = textBox2.Text;
                Seconds = textBox3.Text;

                // Запрещаем редактирование полей после запуска будильника
                textBox1.ReadOnly = true;
                textBox2.ReadOnly = true;
                textBox3.ReadOnly = true;
                button2.Text = "Стоп";

                // Запускаем таймер для проверки времени
                timer1.Start();
            }
        }

        // Обработчик таймера, который каждую 500 мс проверяет системное время
        private void timer1_Tick(object sender, EventArgs e)
        {
            int currentHour = DateTime.Now.Hour;
            int currentMinute = DateTime.Now.Minute;
            int currentSecond = DateTime.Now.Second;

            HourNow = currentHour < 10 ? "0" + currentHour.ToString() : currentHour.ToString();
            MinutesNow = currentMinute < 10 ? "0" + currentMinute.ToString() : currentMinute.ToString();
            SecondsNow = currentSecond < 10 ? "0" + currentSecond.ToString() : currentSecond.ToString();

            // Если системное время совпадает с заданным, воспроизводим аудиофайл
            if (HourNow == Hour && MinutesNow == Minutes && SecondsNow == Seconds)
            {
                PlaySound(NameFile);
                Music = 1;
                timer1.Stop();
                button1.Text = "Выключить музыку";
            }
        }

        // Метод для воспроизведения аудиофайла с помощью NAudio
        private void PlaySound(string filePath)
        {
            try
            {
                StopSound();  // Если аудио уже воспроизводилось, остановим его

                audioFileReader = new AudioFileReader(filePath);
                waveOut = new WaveOutEvent();
                waveOut.Init(audioFileReader);
                waveOut.Play();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при воспроизведении файла: " + ex.Message);
            }
        }

        // Метод для остановки воспроизведения
        private void StopSound()
        {
            if (waveOut != null)
            {
                waveOut.Stop();
                waveOut.Dispose();
                waveOut = null;
            }
            if (audioFileReader != null)
            {
                audioFileReader.Dispose();
                audioFileReader = null;
            }
        }
    }
}
